@extends('leanding-page.template.header-leading-page')
<title>Lihat Antrian</title>
@section('lihat-antrian')
@endsection
@include('leanding-page.template.footer-leading-page')
