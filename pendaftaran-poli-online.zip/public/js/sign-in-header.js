// const pathName = window.location.pathname;
// const pageName = pathName.split("/").pop();

// if (pageName === "sign-in") {
//     document.querySelector(".sign-in").classList.add("activeLink");
// }
// if (pageName === "sign-up") {
//     document.querySelector(".sign-up").classList.add("activeLink");
// }
// if (pageName === "home") {
//     document.querySelector(".home").classList.add("activeLink");
// }
