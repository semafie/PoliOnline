
    


<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="card admin_profile">
        <div class="profile">
            <img
             <?php if(empty($getRecord->image)): ?>
            src="<?php echo e(asset('/assets/img/avatars/1.png')); ?>"
        <?php else: ?>
            src="<?php echo e(asset('storage/img/'. $getRecord->image )); ?>"
        <?php endif; ?>  
        alt="">
            <div class="isi">
                
                <label for="input_id" class="form_label">Nama Akun</label>
                <input type="text" class="form-control input_setengah" id="nama" disabled aria-describedby="defaultFormControlHelp" value="<?php echo e($getRecord->name); ?>" />
                <label for="" class="form_label">email</label>
                <input type="text" class="form-control input_setengah" id="email" disabled aria-describedby="defaultFormControlHelp" value="<?php echo e($getRecord->email); ?>" />
                <label for="" class="form_label">image</label>
                <input type="text" class="form-control input_setengah" id="image" disabled aria-describedby="defaultFormControlHelp" <?php if(empty($getRecord->image)): ?>
                value="-"
            <?php else: ?>
                value="<?php echo e($getRecord->image); ?>"
            <?php endif; ?>/>
                <label for="" class="form_label">no_telp</label>
                <input type="text" class="form-control input_setengah" id="no_telp" disabled aria-describedby="defaultFormControlHelp" <?php if(empty($getRecord->image)): ?>
                value="-"
            <?php else: ?>
                value="<?php echo e($getRecord->no_telp); ?>"
            <?php endif; ?> />
                <div class="isi_btn">
                    <button type="button " class="btn tambah_pasien btn-primary " data-bs-toggle="modal" data-bs-target="#editprofile">Edit Profile</button>
                </div>

                <div class="modal fade" id="editprofile" aria-labelledby="modalToggleLabel" tabindex="-1" style="display: none;" aria-hidden="true">
                    <div class="modal-dialog modal-lg modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="modalToggleLabel">Edit Profile</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="dua_label">
                                <label for="name" class="form-label label_setengah">nama</label>
                                <label for="email" class="form-label label_setengah">email</label>
                            </div>
                            <form action="/admin/profile/edit/<?php echo e($getRecord->id); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="dua_input">
                                <input type="text" class="form-control input_setengah" id="name" name="name" placeholder="Otomatis dibuat sistem" aria-describedby="defaultFormControlHelp" value="<?php echo e($getRecord->name); ?>" />
                                <input type="text" class="form-control input_setengah" id="email" name="email"  placeholder="Masukkan alamat" aria-describedby="defaultFormControlHelp"  value="<?php echo e($getRecord->email); ?>" />
                            </div>
                            <div class="dua_label">
                                <label for="no_telp" class="form-label label_setengah">gambar</label>
                                <label for="image" class="form-label label_setengah">no_telp</label>
                            </div>
                
                            <div class="dua_input">
                                <input class="form-control" type="file" id="image" name="image" />
                                <input type="text" class="form-control input_setengah"id="no_telp" name="no_telp" placeholder="Otomatis dibuat sistem" aria-describedby="defaultFormControlHelp" <?php if(empty($getRecord->image)): ?>
                                value="-"
                            <?php else: ?>
                                value="<?php echo e($getRecord->no_telp); ?>"
                            <?php endif; ?> />
                            </div>
                        </div>
                        <div class="modal-footer">
                          <button type="submit" class="btn btn-primary" data-bs-target="#modalToggle2" data-bs-toggle="modal">Edit Profile</button>
                        </div>
                    </form>
                      </div>
                    </div>
                  </div>
                
            </div>
        </div>
    </div>
</div>


<script>
    <?php if(Session::has('success_message')): ?>
  
    Swal.fire({
      title: 'Berhasil',
      text: 'Data Anda telah ditambahkan...',
      icon: 'success',
      confirmButtonText: 'Oke'
    })
  
    <?php elseif(Session::has('success_edit')): ?>
    Swal.fire({
      title: 'Berhasil',
      text: 'Data anda berhasil di edit...',
      icon: 'success',
      confirmButtonText: 'Oke'
    })
  
    <?php elseif(Session::has('success_delete')): ?>
  
    Swal.fire({
      title: 'Berhasil',
      text: 'Data anda berhasil di Dihapus',
      icon: 'success',
      confirmButtonText: 'Oke'
    })
    <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.template-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Documents\restu\kuliah\semester 4\joki\github akses\pendaftaran-poli-online\resources\views/admin/layout/profile.blade.php ENDPATH**/ ?>