<link rel="stylesheet" href="<?php echo e(asset('css/footer-leanding-page.css ')); ?>">
<div class="footer">


</div>

<footer>
    <div class="footer-row">
        <div class="box-support">
            <div class="box-col">
                <h1>Support</h1>
                <span>Lorem, ipsum.</span>
                <span>Lorem, ipsum.</span>
                <span>Lorem, ipsum.</span>
            </div>
        </div>

        <div class="box-about-us">
            <div class="box-col">
                <h1>About Us</h1>
                <span>Lorem, ipsum.</span>
                <span>Lorem, ipsum.</span>
                <span>Lorem, ipsum.</span>
                <span>Lorem, ipsum.</span>
                <span>Lorem, ipsum.</span>
                <span>Lorem, ipsum.</span>
            </div>

        </div>
        <div class="box-contact">
            <div class="box-col">
                <h1>Contact</h1>
                <span>Lorem, ipsum.</span>
                <span>Lorem, ipsum.</span>
                <span>Lorem, ipsum.</span>
                <span>Lorem, ipsum.</span>
            </div>
        </div>
    </div>
    <div class="box-bottom-footer">
        <h1>Copyright © DBS PoliOnline. 2024</h1>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
</script>
</body>

</html>
<?php /**PATH C:\Users\LENOVO\Documents\restu\kuliah\semester 4\joki\website\pendaftaran-poli-online\resources\views/leanding-page/template/footer-leading-page.blade.php ENDPATH**/ ?>