<link rel="stylesheet" href="<?php echo e(asset('css/sign-up.css')); ?>">
<title>Sign In</title>
<?php $__env->startSection('sign-up'); ?>
    
    <div class="sign-up-container">
        <div class="inner-container">
            <h1>Sign Up</h1>
            
            <form class="form-sign-up">

                <label for="username">Username</label>
                <br>
                <input type="text" placeholder="Masukkan username" required>
                <br>
                <label for="username">Password</label>
                <br>
                <input type="text" placeholder="Masukkan password" required>
                <br>
                <label for="Konfirmasi Password">Password</label>
                <br>
                <input type="text" placeholder="Masukkan konfirmasi password" required>
                <br>
                <button class="btn-register" type="submit">Register</button>
            </form>
            
        </div>
    </div>
    
    <script src="<?php echo e(asset('js/sign-in-header.js')); ?>"></script>

    </body>

    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.header-login-register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Documents\restu\kuliah\semester 4\joki\website\pendaftaran-poli-online\resources\views/sign-up/sign-up.blade.php ENDPATH**/ ?>