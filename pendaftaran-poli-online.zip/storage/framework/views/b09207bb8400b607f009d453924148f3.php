<title>Tentang</title>
<?php $__env->startSection('tentang'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('leanding-page.template.footer-leading-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('leanding-page.template.header-leading-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Documents\restu\kuliah\semester 4\joki\website\pendaftaran-poli-online\resources\views/leanding-page/tentang.blade.php ENDPATH**/ ?>