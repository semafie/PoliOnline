<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="card data_dokter">
      
      <button type="button " class="btn mb-1 btn-primary btn_tambah" data-bs-toggle="modal" data-bs-target="#pilihtanggal">Print</button>
      <div class="modal fade" id="pilihtanggal" aria-labelledby="modalToggleLabel" tabindex="-1" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="modalToggleLabel">Pilih Tanggal</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/admin/cetaklaporan" method="POST" target="_blank">
              <?php echo csrf_field(); ?>
            <div class="modal-body">
              <input class="form-control" type="date" value="2021-06-18" id="tanggal" name="tanggal" />
            </div>
            <div class="modal-footer">
              
              <button class="btn btn-primary" data-bs-target="#modalToggle2" data-bs-toggle="modal" data-bs-dismiss="modal">Print data</button>
            </div>
          </form>
          </div>
        </div>
      </div>
      
        <div class="text-nowrap table-responsive p-3">
            <table id="halo" class="table border-top table-hover">
              <thead>
                <tr>
                    <th>ID</th>
                    <th>No Antrian</th>
                    <th>Nama Pasien</th>
                    <th>Nama Dokter</th>
                    <th>jam</th>
                    <th>tanggal</th>
                    <th>Tujuan Poli</th>
                    <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $Antrian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->no_antrian); ?></td>
                    <td><?php echo e($item->pasien->nama_pasien); ?></td>
                    <td><?php echo e($item->dokter->nama_dokter); ?></td>
                    <td><?php echo e($item->jam); ?></td>
                    <td><?php echo e($item->tanggal); ?></td>
                    <td><?php echo e($item->dokter->nama_poli); ?></td>
                    <td><p class="status_antrian"><?php echo e($item->status); ?></p></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </div>
    </div>
</div>

<script>
  let table = new DataTable('#halo');
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.template-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Documents\restu\kuliah\semester 4\joki\github akses\pendaftaran-poli-online\resources\views/admin/layout/Laporan.blade.php ENDPATH**/ ?>