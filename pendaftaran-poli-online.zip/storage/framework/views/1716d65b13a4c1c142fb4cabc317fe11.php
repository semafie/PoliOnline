<?php $__env->startSection('content'); ?>
<div class="text-nowrap table-responsive p-3">
    <table id="halo" class="table border-top table-hover">
      <thead>
        <tr>
            <th>ID</th>
            <th>No Antrian</th>
            <th>Nama Pasien</th>
            <th>Nama Dokter</th>
            <th>jam</th>
            <th>tanggal</th>
            <th>Tujuan Poli</th>
            <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $Antrian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($item->id); ?></td>
            <td><?php echo e($item->no_antrian); ?></td>
            <td><?php echo e($item->pasien->nama_pasien); ?></td>
            <td><?php echo e($item->dokter->nama_dokter); ?></td>
            <td><?php echo e($item->jam); ?></td>
            <td><?php echo e($item->tanggal); ?></td>
            <td><?php echo e($item->dokter->nama_poli); ?></td>
            <td><p class="status_antrian"><?php echo e($item->status); ?></p>
              
                
              
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.component.sidebare', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Documents\restu\kuliah\semester 4\joki\github akses\pendaftaran-poli-online\resources\views/user/layout/riwayatantrian.blade.php ENDPATH**/ ?>