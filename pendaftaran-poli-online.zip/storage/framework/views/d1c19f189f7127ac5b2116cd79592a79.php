    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <link rel="stylesheet" href="<?php echo e(asset('css/header-leanding-page.css')); ?>">

        
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
    </head>

    <body>
        
        <nav>
            <div class="navbar">
                <a class="logo" href="<?php echo e(route('home')); ?>">Poli<span>Online</span></a>
                <input type="checkbox" id="check">
                <label for="check" class="icon">
                    <i class='bx bx-menu' id="menu-icon"></i>
                    <i class='bx bx-x' id="close-icon"></i>
                </label>
                <ul class="links">
                    <li><a href="<?php echo e(route('home')); ?>" class="active">Home</a></li>
                    <li><a href="#">Tentang</a></li>
                    <li><a href="#">Cara Menggunakan</a></li>
                    <li><a href="#">Lihat Antrian</a></li>
                </ul>
                <div class="btn">
                    <a href="<?php echo e(route('sign-in')); ?>"><button class="btn-login">Sign in</button></a>
                    <a href="<?php echo e(route('sign-up')); ?>"><button class="btn-register">Sign Up</button></a>
                </div>
            </div>
        </nav>


        
        <?php echo $__env->yieldContent('leanding-page'); ?>
        
<?php /**PATH C:\Users\LENOVO\Documents\restu\kuliah\semester 4\joki\website\pendaftaran-poli-online\resources\views/leanding-page/template/header-leading-page.blade.php ENDPATH**/ ?>