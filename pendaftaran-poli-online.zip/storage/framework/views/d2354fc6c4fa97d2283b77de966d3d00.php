<?php $__env->startSection('content'); ?>
    
<div class="container-xxl flex-grow-1 container-p-y">
  <div class="card dashboard">
    <div class="container">
      <img style="filter: blur(0.8px); width: 300px; height: 300px;" src="<?php echo e(asset('img/logo_si.png')); ?>" alt="">
    </div>
    
  </div>
</div>


  <script>
    <?php if(Session::has('success_message')): ?>
  
    Swal.fire({
      title: 'Berhasil',
      text: 'Anda telah berhasil Login...',
      icon: 'success',
      confirmButtonText: 'Oke'
    })
  
    <?php elseif(Session::has('success_edit')): ?>
    Swal.fire({
      title: 'Berhasil',
      text: 'Data anda berhasil di edit...',
      icon: 'success',
      confirmButtonText: 'Oke'
    })
  
    <?php elseif(Session::has('success_delete')): ?>
  
    Swal.fire({
      title: 'Berhasil',
      text: 'Data anda berhasil di Dihapus',
      icon: 'success',
      confirmButtonText: 'Oke'
    })
    <?php endif; ?>
    </script>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.template-header-poli', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Documents\restu\kuliah\semester 4\joki\github akses\pendaftaran-poli-online\resources\views/admin/layout/dashboard_poli.blade.php ENDPATH**/ ?>