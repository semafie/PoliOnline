    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        
        <link rel="stylesheet" href="<?php echo e(asset('css/header-leanding-page.css')); ?>">
        
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
    </head>

    <body>
        
        <nav>
            <div class="navbar">
                <a class="logo" href="<?php echo e(route('home')); ?>"><img class="logosidebar" src="<?php echo e(asset('/img/logo_si.png')); ?>" alt="">Sip<span>PH.</span></a>
                <input type="checkbox" id="check">
                <label for="check" class="icon">
                    <i class='bx bx-menu' id="menu-icon"></i>
                    <i class='bx bx-x' id="close-icon"></i>
                </label>
                <ul class="links mb-0">
                    <li><a onclick="scrollToTargetkemabali()" >Home</a></li>
                    <li><a onclick="scrollToTarget_tentang()">Tentang</a></li>
                    <li><a onclick="scrollToTarget_caramenggunakan()">Cara Menggunakan</a></li>
                    <li><a onclick="scrollToTarget_lihatantrian()" >Lihat Antrian</a></li>
                </ul>
                <?php if($getRecord === 'kosong'): ?>
                <div class="btn">
                    <a href="<?php echo e(route('sign-in')); ?>"><button class="btn-login">Sign in</button></a>
                    <a href="<?php echo e(route('sign-up')); ?>"><button class="btn-register">Sign Up</button></a>
                </div>
                <?php else: ?>
                <div class="sudah_login">
                    <p><?php echo e($getRecord->name); ?></p>
                    <a href="" data-bs-toggle="dropdown"><img <?php if(empty($getRecord->image)): ?>
                        src="<?php echo e(asset('/assets/img/avatars/1.png')); ?>"
                    <?php else: ?>
                        src="<?php echo e(asset('storage/img/'. $getRecord->image )); ?>"
                    <?php endif; ?> alt=""></a>
                    <ul class="dropdown-menu" style="left: auto">
                        <li> <a class="dropdown-item" 
                            <?php if($getRecord->role == 'admin_pendaftaran'): ?>
                             href="<?php echo e(route('admin_dashboard')); ?>"
                             <?php elseif($getRecord->role == 'admin_poli'): ?>
                             href="<?php echo e(route('admin_poli_dashboard')); ?>"
                             <?php else: ?>
                             href="<?php echo e(route('user_antrians')); ?>"
                             <?php endif; ?>
                             >Dashboard</a> </li>
                        <li>
                          <hr class="dropdown-divider">
                        </li>
                        <li> <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a> </li>
                      </ul>
                </div>
                <?php endif; ?>
                
                
            </div>
        </nav>


        
        <?php echo $__env->yieldContent('leanding-page'); ?>
        

        <script>window.addEventListener("scroll", function() {
            var navbar = document.querySelector("nav");
            var scroll = window.scrollY;
            navbar.classList.toggle("active", scroll > 1);
        });
            </script><?php /**PATH C:\Users\LENOVO\Documents\restu\kuliah\semester 4\joki\github akses\pendaftaran-poli-online\resources\views/leanding-page/template/header-leading-page.blade.php ENDPATH**/ ?>