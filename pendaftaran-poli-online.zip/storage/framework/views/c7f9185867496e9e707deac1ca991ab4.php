<link rel="stylesheet" href="<?php echo e(asset('css/sign-in.css')); ?>">
<title>Sign In</title>
<?php $__env->startSection('sign-in'); ?>
    
    <div class="sign-in-container">
        <div class="inner-container">
            <h1>Sign In</h1>
            
            <div class="form-sign-in">

            <form action="/authentication" method="POST">
                <?php echo csrf_field(); ?>
                <label for="email">Username</label>
                <br>    
                <input type="email" name="email" placeholder="Masukkan email" class="" required>
                <br>
                
                <label for="password">Password</label>
                <br>
                <input type="password" name="password" placeholder="Masukkan password" required>
                <div class="lupa-password">
                    <a href="#">Lupa password?</a>
                </div>
                <button class="btn-login" type="submit">Login</button>
                </form>
                <h2>OR</h2>
                <a href="auth/redirect">
                <div class="btn-login-with-google" type="submit">
                    <img src="<?php echo e(asset('img/google.png')); ?>" alt="">
                    Masuk/Daftar dengan google
                </div>
                </a>
                            
            </div>
            
        </div>
    </div>
    
    <script src="<?php echo e(asset('js/sign-in-header.js')); ?>"></script>

    <script>
  <?php if(Session::has('gagal_login')): ?>
  Swal.fire({
    title: 'Gagal Login',
    text: 'Coba cek email atau password kembali',
    icon: 'error',
    confirmButtonText: 'Oke'
  })

  <?php elseif(Session::has('login_dulu')): ?>
  Swal.fire({
    title: 'Anda Belum Login',
    text: 'Coba login terlebih dahulu',
    icon: 'error',
    confirmButtonText: 'Oke'
  })

  <?php elseif(Session::has('success_delete')): ?>

  Swal.fire({
    title: 'Berhasil',
    text: 'Data anda berhasil di Dihapus',
    icon: 'success',
    confirmButtonText: 'Oke'
  })
  <?php elseif(Session::has('berhasil register')): ?>

  Swal.fire({
    title: 'Berhasil',
    text: 'Anda berhasil registrasi',
    icon: 'success',
    confirmButtonText: 'Oke'
  })
  <?php endif; ?>
  </script>

    </body>

    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.header-login-register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Documents\restu\kuliah\semester 4\joki\github akses\pendaftaran-poli-online\resources\views/sign-in/sign-in.blade.php ENDPATH**/ ?>