<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/sign-in-header.css')); ?>">
    <script defer src="<?php echo e(asset('js/sign-in-header.js')); ?>"></script>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.all.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.min.css" rel="stylesheet">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
</head>

<body>
    
    <header>
        <div class="navbar">
            <div class="logo"><img class="logosidebar" src="<?php echo e(asset('/img/logo_si.png')); ?>" alt=""><a href="<?php echo e(route('home')); ?>">Sip<span>PH.</span></a></div>
            <ul class="links">
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li><a href="<?php echo e(route('sign-in')); ?>" class="<?= Irsyadulibad\LaravelActivehelper\ActiveHelper::echo('sign-in') ?>">Sign In</a></li>
                <li><a href="<?php echo e(route('sign-up')); ?>" class="<?= Irsyadulibad\LaravelActivehelper\ActiveHelper::echo('sign-up') ?>">Sign Up</a></li>
            </ul>
        </div>
    </header>
    
    <?php echo $__env->yieldContent('sign-in'); ?>
    <?php echo $__env->yieldContent('sign-up'); ?>
<?php /**PATH C:\Users\LENOVO\Documents\restu\kuliah\semester 4\joki\github akses\pendaftaran-poli-online\resources\views/templates/header-login-register.blade.php ENDPATH**/ ?>