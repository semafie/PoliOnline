<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="card data_dokter">
        <div class="text-nowrap table-responsive p-3">
            <table id="myTable" class="table border-top table-hover">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>No Rm</th>
                  <th>Nama Pasien</th>
                  <th>nama_dokter</th>
                  <th>jam</th>
                  <th>tanggal</th>
                  <th>Tujuan Poli</th>
                  <th>Status</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
              <?php $__currentLoopData = $Antrian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->no_antrian); ?></td>
                    <td><?php echo e($item->pasien->nama_pasien); ?></td>
                    <td><?php if(!empty($item->dokter->nama_dokter)): ?>
                      <?php echo e($item->dokter->nama_dokter); ?>

                  <?php else: ?>
                      Belum Ada Dokter
                  <?php endif; ?></td>
                    <td><?php echo e($item->jam); ?></td>
                    <td><?php echo e($item->tanggal); ?></td>
                    <td><?php
                      $firstChar = strtoupper(substr($item->no_antrian, 0, 1));
                      $poli = '';
                      switch ($firstChar) {
                          case 'A':
                              $poli = 'Poli Umum';
                              break;
                          case 'B':
                              $poli = 'Poli Gigi';
                              break;
                          case 'C':
                              $poli = 'Poli Kia';
                              break;
                          default:
                              $poli = 'Tidak Diketahui';
                      }
                      echo $poli;
                  ?></td>
                    <td><p class="status_antrian"><?php echo e($item->status); ?></p>
                      
                        
                      
                    </td>
                    <td><button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#pilihdokter<?php echo e($item->id); ?>">Pilih Dokter</button></td>
                  </tr>
                  <div class="modal fade" id="pilihdokter<?php echo e($item->id); ?>" aria-labelledby="modalToggleLabel" tabindex="-1" style="display: none;" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="modalToggleLabel">Pilih dokter</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form action="/admin/permintaan_antrian/edit_dokter/<?php echo e($item->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        
                        <div class="modal-body">
                          <div class="dua_label">
                            <label for="input_id" class="form-label label_setengah">Jenis POli</label>
                            <label for="input_alamat" class="form-label label_setengah">NAma Dokter</label>
                        </div>
            
                        <div class="dua_input">
                          <input type="text" class="form-control input_setengah" readonly id="input_nama_poli1" name="input_alamat" placeholder="Masukkan Jenis Poli" aria-describedby="defaultFormControlHelp" value="<?php
                            $firstChar = strtoupper(substr($item->no_antrian, 0, 1));
                            $poli = '';
                            switch ($firstChar) {
                                case 'A':
                                    $poli = 'Poli Umum';
                                    break;
                                case 'B':
                                    $poli = 'Poli Gigi';
                                    break;
                                case 'C':
                                    $poli = 'Poli Kia';
                                    break;
                                default:
                                    $poli = 'Tidak Diketahui';
                            }
                            echo $poli;
                        ?>" />
                          <select id="selectdokter" name="selectdokter" class="form-select">
                            
                            
                            <?php $__currentLoopData = $Dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($dokter->nama_poli ===   $poli ): ?>
                                <option value="<?php echo e($dokter->id); ?>"><?php echo e($dokter->nama_dokter); ?> </option> 
                                
                            <?php endif; ?>
                              
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </select>
                            
                        </div>
                        
                        </div>
                        
                        <div class="modal-footer">
                          
                          <button type="submit" class="btn btn-primary" data-bs-target="#ambildokter" data-bs-toggle="modal" data-bs-dismiss="modal">Pilih Dokter</button>
                        </div>
                      </form>
                      </div>
                    </div>
                  </div>

                  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </tbody>
            </table>
        </div>
    </div>
</div>






<script>
  let table = new DataTable('#myTable');
  let table1 = new DataTable('#tabeldokter');
  </script>

<script>
  <?php if(Session::has('success_message')): ?>

  Swal.fire({
    title: 'Berhasil ',
    text: 'Data dokter telah ditambahkan...',
    icon: 'success',
    confirmButtonText: 'Oke'
  })

  <?php elseif(Session::has('success_edit')): ?>
  Swal.fire({
    title: 'Berhasil',
    text: 'Data anda berhasil di edit...',
    icon: 'success',
    confirmButtonText: 'Oke'
  })

  <?php elseif(Session::has('success_delete')): ?>

  Swal.fire({
    title: 'Berhasil',
    text: 'Data anda berhasil di Dihapus',
    icon: 'success',
    confirmButtonText: 'Oke'
  })
  <?php endif; ?>
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.template-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Documents\restu\kuliah\semester 4\joki\github akses\pendaftaran-poli-online\resources\views/admin/layout/permintaan_antrian.blade.php ENDPATH**/ ?>