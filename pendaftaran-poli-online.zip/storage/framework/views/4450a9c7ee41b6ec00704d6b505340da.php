<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <a href="<?php echo e(route('cetak')); ?>">cetak</a>
</body>
</html><?php /**PATH C:\Users\LENOVO\Documents\restu\kuliah\semester 4\joki\website\pendaftaran-poli-online\resources\views/welcome.blade.php ENDPATH**/ ?>